from dc import App

app = App()

app.run_server()